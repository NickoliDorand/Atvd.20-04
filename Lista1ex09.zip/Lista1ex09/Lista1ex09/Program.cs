﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diametro;
            double resultado;

            Console.Write("Digite o diametro para ser calculado: ");
            diametro = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = Math.PI * Math.Pow(diametro/2, 2);
            Console.Write(" A Area do circulo corresponde:{0}", resultado);
            Console.WriteLine();
        }
    }
}
