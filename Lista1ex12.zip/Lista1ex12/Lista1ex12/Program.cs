﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double objt1;
            double objt2;
            double objt3;
            double objt4;
            double objt5;
            double pagamento;
            double troco;
            double valortotal;



            Console.Write("Digite o valor do primeiro objeto: ");
            objt1= double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do segundo objeto: ");
            objt2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do terceiro objeto: ");
            objt3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do quarto objeto: ");
            objt4 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do quinto objeto: ");
            objt5 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            valortotal = objt1+objt2+objt3+objt4+objt5;
            Console.Write("O valor total é: ${0} ", valortotal);
            Console.WriteLine();
            Console.WriteLine();

            Console.Write("Digte o pagamento:");
            pagamento = double.Parse(Console.ReadLine());
            Console.WriteLine();


            troco = pagamento - valortotal;
            Console.Write("Seu troco é: ${0} ", troco);
            Console.WriteLine();


        }

    }
}
