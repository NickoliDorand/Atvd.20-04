﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1exercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int altura1; 
            int base2;
            int resultadoarea;

            Console.Write("Digite a altura: ");
            altura1 = int.Parse(Console.ReadLine());

            Console.Write("Digite a base: ");
            base2 = int.Parse(Console.ReadLine());

            resultadoarea = base2 * altura1;
            Console.WriteLine("O resultado da base vezes a altura é: {2} ", altura1, base2, resultadoarea);
            resultadoarea = altura1 * base2;






        }
    }
}
