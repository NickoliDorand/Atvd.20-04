﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valordolar;
            double valorcotacao;
            double resultado;

            Console.Write("Digite o Valor da Cotação do Dólar: R$ ");
            valorcotacao = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite um Valor em Dólares: US$ ");
            valordolar = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = valordolar * valorcotacao;
            Console.WriteLine("Resultado em Reais: {0}", resultado.ToString("C"));
            Console.WriteLine();

        }
    }
}
