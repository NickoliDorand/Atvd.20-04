﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double n3;
            double n4;
            double resultado;

            Console.Write("Digite o primeiro valor: ");
            n1=double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o segundo valor: ");
            n2=double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o terceito valor: ");
            n3= double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Agora o último valor: ");
            n4=double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = (n1 + n2 + n3 + n4) / 4;
            Console.WriteLine("A média aritmética nesse caso é: " + resultado);
            Console.WriteLine();


        }
    }
}
