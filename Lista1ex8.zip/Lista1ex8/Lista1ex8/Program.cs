﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double GrauCelsus;
            double resultado;

            Console.Write("Digite a Temperatura que deseja converter: ");
            GrauCelsus = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = GrauCelsus * 1.8 + 32;
            Console.WriteLine(" A temperatura convertida em Fahrenheit :{0}ºF", resultado);
            Console.WriteLine();
        }
    }
}
