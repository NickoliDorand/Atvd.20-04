﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;
            
            Console.Write("Digite um valor em Milha Marítima: ");
            valor = double.Parse(Console.ReadLine());
            resultado = valor * 1.852;
            Console.WriteLine();


            Console.WriteLine("Resultado em Quilômetro: {0}", resultado);
            Console.WriteLine();





        }
    }
}
