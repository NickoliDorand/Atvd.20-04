﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double milhas;
            double resultado;

            Console.Write("digite a quantidade de milhas que deseja converter em kilometros: ");
            milhas = double.Parse(Console.ReadLine());

            resultado= milhas * 1.609;
            Console.WriteLine(" o resultado em kilometros e:{0} km", resultado);

            

            
            
        }
    }
}
