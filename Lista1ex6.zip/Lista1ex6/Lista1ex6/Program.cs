﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double resultado;

            Console.Write("Digite o primeiro valor: ");
            valor1=double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o segundo valor: ");
            valor2 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = (valor1 * valor2);
            resultado = Math.Sqrt(resultado);
            Console.WriteLine("A média geométrica é: "+ resultado);
        }
    }
}
