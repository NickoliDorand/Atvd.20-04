﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            double resultado;

            Console.Write("Divite a base: ");
            x= double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Agora o expoênte: ");
            y= double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = Math.Pow (x,y);
            Console.WriteLine();

            Console.Write("Resultado do cálculo é: {0} ", resultado);
            Console.WriteLine();
            Console.WriteLine();

        }
    }
}
