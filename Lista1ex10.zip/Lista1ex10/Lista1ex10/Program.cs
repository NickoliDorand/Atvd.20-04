﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double dolar;
            double reais;
            double resultado;

            Console.Write("Diga quanto você tem em dólares: ");
            dolar=double.Parse(Console.ReadLine());
           

            resultado = dolar*4.97;
            Console.WriteLine();

            Console.Write("Esse é a quantidade obtida em reais: {0}", resultado);
            Console.WriteLine();
            Console.WriteLine();


        }
    }
}
