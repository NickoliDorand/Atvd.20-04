﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double tbase;
            double altura;
            double resultado;
            double variável;

            Console.Write("Digite a base do triangulo|: ");
            tbase =double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Agora a altura: ");
            altura = double.Parse(Console.ReadLine());
            Console.WriteLine();

            variável = altura * tbase;
            resultado = variável / 2;
            Console.Write("O resultado é: " + resultado);
            Console.WriteLine();


        }
    }
}
