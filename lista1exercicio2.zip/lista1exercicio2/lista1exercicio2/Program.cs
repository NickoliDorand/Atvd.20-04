﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1exercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int lados1;
            int resultado2;
            Console.WriteLine("Vamos calcular a área do quadrado ");
            Console.WriteLine();

            Console.Write("Digite o lado do quadrado: ");
            lados1=int.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado2 = lados1 * lados1;
            Console.WriteLine("O resultado da área do quadrado será: {1} ", lados1, resultado2);
            resultado2 = lados1 * lados1;
            Console.WriteLine();






        }
    }
}
