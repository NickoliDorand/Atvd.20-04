﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double lado;
            double diagonal;
            double resultado;

            Console.Write("Digite a diagonal do quadrado: ");
            diagonal = double.Parse(Console.ReadLine());
            Console.WriteLine();

            lado = diagonal / Math.Sqrt (2);
            resultado = Math.Pow(lado, 2);
            Console.WriteLine(" O resultado da área é:  {0} ", resultado);
            Console.WriteLine();
            
        }
    }
}
